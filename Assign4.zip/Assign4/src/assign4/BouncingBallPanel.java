/*
 * Assignment 4
 * Name: Lukus Hendrix
 * ZID: Z1761354
 * CSCI 470
 * Date Due: 4/16/18
 * Description: This is a subclass of JPanel and encapsulates the balls animation. 
               This will also handle start and stop the button events.               
 *               
*/
package assign4;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BouncingBallPanel extends JPanel implements ActionListener
{
    private AnimationPanel animationPanel;
    private JButton startBt;
    private JButton stopBt;
    

    // This constructor creates the panel what it contains.
    public BouncingBallPanel()
    {
        // Calls super contructor, sets size and borderlayout of panel.
        super();
        setLayout( new BorderLayout() );
        setPreferredSize(new Dimension(400, 600));

        // Creates the Start button and action listener
        startBt = new JButton("Start");
        startBt.addActionListener(this);

        // Creates the Stop button and action listener, and sets enabled to false.
        stopBt = new JButton("Stop");
        stopBt.addActionListener(this);
        stopBt.setEnabled( false );

        // This creates a panel to hold the start and stop buttons.
        JPanel buttonPanel = new JPanel( new FlowLayout( FlowLayout.CENTER ) );
        buttonPanel.add(startBt);
        buttonPanel.add(stopBt);

        // This creates a new AnimationPanel
        animationPanel = new AnimationPanel();

        // This adds the buttonPanel and animationPanel to new panel.
        add(buttonPanel, BorderLayout.PAGE_START);
        add(animationPanel, BorderLayout.CENTER);
    }

    // This implements a action listener for the start, stop buttons.
    @Override
    public void actionPerformed(ActionEvent e)
    {
        // If the start button, call the start method,
        // set startbt to false and stopbt to true
        
        if( e.getSource() == startBt)
        {
            animationPanel.start();
            startBt.setEnabled(false);
            stopBt.setEnabled(true);
        }

        // If the stop button, call the stop method,
        // set startbt to true and stopbt to false
        else if( e.getSource() == stopBt)
        {
            animationPanel.stop();
            startBt.setEnabled(true);
            stopBt.setEnabled(false);
            
        }
    }
}
