/*
 * Assignment 3
 * Name: Lukus Hendrix
 * ZID: Z1761354
 * CSCI 470
 * Date Due: 4/4/18
 * Description: This contains the main class, and extends JFrame. It has a menu bar
                and handles the events from the menu bar’s menu items.

 *               
*/

package assign4;

import java.io.FileNotFoundException;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;



public class XMLDownloader extends JFrame implements ActionListener
{

    private static XMLDownloadPanel xmlDownloadPanel;
    
    private static BouncingBallPanel bouncingBallPanel;


    // This main method creates the frame and populates the createAndShowGUI method when call.
    public static void main(String[] args)
    {
        EventQueue.invokeLater(() -> {
            XMLDownloader frame = new XMLDownloader("iTunes Store Albums");
            frame.createAndShowGUI();

        });
    }

    // Constructor for JFrame
    private XMLDownloader(String title){
        // Sets title
        super(title);
    }

    // This sets the layout, calls the createMenu method, 
    // initializes the xmlDownloadPanel and adds it to the JFrame.
    private void createAndShowGUI()
    {
        setLayout( new BorderLayout() );
        setDefaultCloseOperation( EXIT_ON_CLOSE );

        createMenu();

        xmlDownloadPanel = new XMLDownloadPanel();
        add(xmlDownloadPanel, BorderLayout.CENTER);
       
    // initializes the bouncingBallPanel and adds it to the JFrame
        bouncingBallPanel = new BouncingBallPanel();
        add(bouncingBallPanel, BorderLayout.LINE_END);

        pack();
        // displays the GUI and sets size.
        setSize(1000, 550);
        setVisible(true);
    }
// This creates the menu bar 
    private void createMenu()
    {
        JMenuBar menuBar = new JMenuBar();
        JMenu menu;
        JRadioButtonMenuItem menuItem;
        ButtonGroup group;

        // Creates the Type menu 
        menu = new JMenu("Type");
        menu.setMnemonic(KeyEvent.VK_T);
        group = new ButtonGroup();

        // Creates the new music menu item
        menuItem = new JRadioButtonMenuItem("New Music");
        menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_M,
                Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        menuItem.setSelected(true);
        menuItem.addActionListener(this);
        group.add(menuItem);
        menu.add(menuItem);

        // Creates the recent releases menu item
        menuItem = new JRadioButtonMenuItem("Recent Releases");
        menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R,
                Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        menuItem.addActionListener(this);
        group.add(menuItem);
        menu.add(menuItem);

        // Creates the top albums menu item
        menuItem = new JRadioButtonMenuItem("Top Albums");
        menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_T,
                Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        menuItem.addActionListener(this);
        group.add(menuItem);
        menu.add(menuItem);

        menuBar.add(menu);

        // Creates the Limit Menu
        menu = new JMenu("Limit");
        menu.setMnemonic(KeyEvent.VK_L);
        group = new ButtonGroup();

        // Creates the 10 menu item
        menuItem = new JRadioButtonMenuItem("10");
        menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_1,
                Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        menuItem.setSelected(true);
        menuItem.addActionListener(this);
        group.add(menuItem);
        menu.add(menuItem);

        // Creates the 25 menu item
        menuItem = new JRadioButtonMenuItem("25");
        menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_2,
                Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        menuItem.addActionListener(this);
        group.add(menuItem);
        menu.add(menuItem);

        // Creates the 50 menu item
        menuItem = new JRadioButtonMenuItem("50");
        menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_5,
                Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        menuItem.addActionListener(this);
        group.add(menuItem);
        menu.add(menuItem);

        // Creates the 100 menu item
        menuItem = new JRadioButtonMenuItem("100");
        menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_0,
                Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        menuItem.addActionListener(this);
        group.add(menuItem);
        menu.add(menuItem);

        menuBar.add(menu);

        // Creates the Explicit Menu
        menu = new JMenu("Explicit");
        menu.setMnemonic(KeyEvent.VK_E);
        group = new ButtonGroup();

        // Creates the yes menu item
        menuItem = new JRadioButtonMenuItem("Yes");
        menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Y,
             Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        menuItem.addActionListener(this);
        menuItem.setSelected(true);
        group.add(menuItem);
        menu.add(menuItem);

        // Creates the no menu item
        menuItem = new JRadioButtonMenuItem("No");
        menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,
             Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        menuItem.addActionListener(this);
        menuItem.setSelected(true);
        group.add(menuItem);
        menu.add(menuItem);

        menuBar.add(menu);

        // sets the JMenuBar to the created menuBar.
        setJMenuBar( menuBar );
    }
 
       
  
  // This sets the case to what is selected for the menu item.
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
          case "New Music":
                xmlDownloadPanel.setFeedType( "new-music" );
                break;

            case "Recent Releases":
                xmlDownloadPanel.setFeedType( "recent-releases" );
                break;

            case "Top Albums":
                xmlDownloadPanel.setFeedType( "top-albums" );
                break;

            case "10": case "25": case "50": case "100":
                xmlDownloadPanel.setResultLimit( Integer.parseInt( e.getActionCommand() ));
                break;

            case "Yes": case "No":
               xmlDownloadPanel.setExplicit( Boolean.parseBoolean( e.getActionCommand() ));
                break;

        } 
   }
    
}
    

