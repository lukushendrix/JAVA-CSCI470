/*
 * Assignment 3
 * Name: Lukus Hendrix
 * ZID: Z1761354
 * CSCI 470
 * Date Due: 4/4/18
 * Description: This is a subclass of SwingWorker that is used to 
 *          download the XML data in a background thread.
 *          This class adds the published Album objects using an
 *          Arraylist and returns the list when the task is complete
 *          to be displayed.
 *               
*/
package assign4;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.ByteArrayInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import org.xml.sax.InputSource;
import java.net.URL;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.SAXException;
import org.xml.sax.Attributes;

public class XMLDownloadTask extends SwingWorker<ArrayList<Album>, Album>
{
    private ArrayList<Album> albums;
    private String urlStr;
    private AlbumDisplayer display;
    

    // This constructor sets the display, urlStr, and creates a new ArrayList.
    XMLDownloadTask( AlbumDisplayer setDisplay, String setUrl)
    {
        albums = new ArrayList<>();
        display = setDisplay;
        urlStr = setUrl;
        
    }

    // Initializes the background thread to download the album information.
    @Override
    public ArrayList<Album> doInBackground()
    {
        String xmlStr;
        HttpURLConnection connection = null;

        try
        {
            URL url = new URL( urlStr );

            // Opens connection for the URL
            connection = (HttpURLConnection)url.openConnection();

            // Requests the information.
            connection.setRequestMethod("GET");

            // If it connects, it will start creating the string, saving it to the xmlStr.
            if (connection.getResponseCode() == HttpURLConnection.HTTP_OK)
            {
                StringBuilder xmlResponse = new StringBuilder();
                BufferedReader input = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                        
               //Appends the line 
                String strLine;

                while((strLine = input.readLine()) != null)
                    xmlResponse.append(strLine);

                xmlStr = xmlResponse.toString();

                // Uses the sacParser to parse the current xml string.
                try
                {
                    SAXParserFactory factory = SAXParserFactory.newInstance();
                    SAXParser saxParser = factory.newSAXParser();

                    saxParser.parse(new InputSource(new ByteArrayInputStream(
                            xmlStr.getBytes("utf-8"))), new AlbumHandler());
                }
                catch (ParserConfigurationException e)
                {
                    System.out.println("Error: ParserConfigurationException thrown");
                }
                catch (SAXException e)
                {
                    System.out.println("Error: SAXException thrown");
                }
                input.close();
            }
        }
        catch (MalformedURLException e)
        {
            System.out.println("Error: Invalid URL.");
        }
        catch (IOException e)
        {
            System.out.println("Error: could not open connection.");
        }
        // This finalizes the disconnect.
        finally
        {
            if (connection != null)
                connection.disconnect();
        }

        // Returns ArrayList of albums.
        return albums;
    }

    // Calls the disAlbums method for each album processed.
    @Override
    protected void process(List<Album> parts)
    {
        for (Album album : parts)
            display.displayAlbums(album);
    }

    // Class Name:  AlbumHandler
    // Description:
    // This is an inner class of the XMLDownloadTask class and a subclass
    // of the DefaultHandler. This will parse the url string and 
    // append a new album with the information it has about the url string. 
   
    public class AlbumHandler extends DefaultHandler
    {
        private boolean boolName = false;
        private boolean boolArtist = false;
        private boolean category = true;

        private String name, artist, label;

        // This checks the first tag and sets it to true if it is found.
        public void startElement(String ur, String localN, String aName, Attributes attributes)
        {
            if (aName.equalsIgnoreCase("im:name"))
            {
                boolName = true;
                name = "";
            }

            if (aName.equalsIgnoreCase("im:artist"))
            {
                boolArtist = true;
                artist = "";
            }

            // Sets the label to the attribute of the category to false. 
            
            if (aName.equalsIgnoreCase("category") && category)
            {
                label = attributes.getValue("label");
                category = false;
            }
        }

        //  Depending on which tag was found, this will set the name or the artist.
        public void characters(char ch[], int start, int length)
        {
            if (boolName)
                name = name + new String(ch, start, length);

            if (boolArtist)
                artist = artist + new String(ch, start, length);
        }

        // This sets the matching boolean to false, after it finds matching tags.
        public void endElement(String uri, String localName, String aName)
        {
            if (aName.equalsIgnoreCase("im:name"))
                boolName = false;

            if (aName.equalsIgnoreCase("im:artist"))
                boolArtist =false;

            // This sets category to true, makes a new album, then publish the album.
            if (aName.equalsIgnoreCase("entry"))
            {
                category = true;
                Album album = new Album(name, artist, label);
                publish(album);
            }
        }
    }
}



// This is an interface used by the displayAlbum method.
interface AlbumDisplayer
{
    void displayAlbums( Album album );
}
