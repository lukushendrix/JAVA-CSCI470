/*
 * Assignment 4
 * Name: Lukus Hendrix
 * ZID: Z1761354
 * CSCI 470
 * Date Due: 4/16/18
 * Description: This subclass of JPanel will be used to display the animation
        in a separate background thread. This Implements the Runnable interface. 
                
 *               
*/
package assign4;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class AnimationPanel extends JPanel implements Runnable
{
    private ArrayList<Ball> ballList = new ArrayList<>();      
    private volatile Thread thread = null;
    private Dimension dimension = null;

    // This starts the animation
    public void start()
    {
  // If the thread is equal to null, create a new thread. Then call the start method.
        if( thread == null)
        {
            thread = new Thread(this);
            thread.start();
        }
    }

    // Interrupt the thread and set it to null to stop it.
    public void stop()
    {
        thread.interrupt();
        thread = null;
    }

  // This method creates each balls, and continuously runs new threads to animate.
    @Override
     protected void paintComponent(Graphics g)
    {
        // Calls the super version
         super.paintComponent(g);

        // if the dimensions are null, set the dimension using getSize and populate the ballList.
        if( dimension == null )
        {
            dimension = getSize();
            ballList.add(new Ball(Color.GREEN, 20, (dimension.width / 2 ), (dimension.height / 2), -2, -4));
            ballList.add(new Ball(Color.BLUE, 20, (dimension.width / 2), (dimension.height / 2), -4, 7));        
            ballList.add(new Ball(Color.RED, 20, (dimension.width / 2), (dimension.height / 2), 1, 6));
       
        }

        // This creates the black background for the balls.
        g.setColor( Color.BLACK );
        g.fillRect( 0, 0, dimension.width, dimension.height );

        // This calls the draw and move method for each ball in the ballList.
        for (Ball ball : ballList)
        {
            ball.draw(g);
            ball.move(dimension);
        }
    }

    // This will function in the main method for the created thread.
    public void run()
    {
        // while thread isn't null
        while (Thread.currentThread() == thread )
        {
            // Have thread sleep for 25 milliseconds.
            try
            {
                Thread.sleep(25);
            }
            //  Exit if interrupted.
            catch( InterruptedException e )
            {
                return;
            }

      // This calls the paintComponent method.
            repaint();
        }
    }


}
