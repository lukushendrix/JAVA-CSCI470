/*
 * Assignment 3
 * Name: Lukus Hendrix
 * ZID: Z1761354
 * CSCI 470
 * Date Due: 4/4/18
 * Description: This class holds all of the information about an album.
 *               
*/
package assign4;

public class Album
{
    private String albumName, artistName, genre;

    public Album() {
      
    }

   
    // Sets the variables to Strings.
   
    public Album( String album, String artist, String gen )
    {  
        artistName = artist;
        genre = gen;
        albumName = album;
    }

       // Accessors for the artistName
    public String getArtistName() { return artistName; }
    public void setArtistName( String newName ) { artistName = newName; }

    // Accessors for the genre
    public String getGenre() { return genre; }
    public void setGenre( String newGenre) { genre = newGenre; }
    
    // Accessors for the albumName
    public String getAlbumName() { return albumName; }
    public void setAlbumName( String newName ) { albumName = newName; }
    
}
