/*
 * Assignment 4
 * Name: Lukus Hendrix
 * ZID: Z1761354
 * CSCI 470
 * Date Due: 4/16/18
 * Description: This class contains the components that creates
                a single bouncing ball in the animation. 
 *               
*/
package assign4;

import java.awt.*;

public class Ball
{
    private Color color;
    private int radius;    
    private int cordY;  
    private int cordX;
    private int dy;
    private int dx;
    // This constructor sets the attributes of each variable.
    public Ball( Color newColor, int newRadius, int nX, int nY, int nDX, int nDY )
    {
        color = newColor;
        radius = newRadius;
        cordX = nX;
        cordY = nY;
        dx = nDX;
        dy = nDY;
    }

    // This move method changes the cordX and cordY based on the dx and dy response.
    public void move( Dimension d )
    {
        // if the cordX hits the wall inside the panel, the direction will change.
        if( cordX <= radius || cordX >= (d.width - radius) )
            dx = dx * -1;

        // if the cordY hits the wall inside the panel, the direction will change.
        if( cordY <= radius || cordY >= (d.height - radius) )
            dy = dy * -1;

        // Updates the cordX and cordY.
        cordX += dx;
        cordY += dy;
    }

    // Draws and fills the ball based on the cordX, cordY, and the radius.
    public void draw( Graphics g)
    {
        g.setColor( color );

        g.fillOval( (cordX - radius), (cordY - radius), (radius * 2), (radius * 2) );
    }
}

