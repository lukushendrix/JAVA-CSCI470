/* Assignment 2
 * Name Lukus Hendrix
 * ZID z1761354
 * CSCI 470
 * Date Due: 3/21/18
 * Description: This class is used to hold the methods containing algorithms 
 * to read calculate and display the input file. 
 */
package assign2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;


public class MilesRedeemer
{
    private ArrayList<Destination> destinations;
    private int remainMiles;

    // Default Constructor setting remaining miles to 0 and allocates destinations memory.
    public MilesRedeemer()
    {       
        remainMiles = 0;
        destinations = new ArrayList<>();
    }
    // uses Arraylist to gets the names of the destination cities 
    public String[] getCityNames()
    {
         // Sets size of the array to = destination ArrayList
        String[] city = new String[destinations.size()];

      // stores the destinations ArrayList into city 
        for( int i = 0; i < destinations.size(); ++i)
            city[i] = destinations.get(i).getDestinationCity();
        
        Arrays.sort( city);

        return city;
    }
    
    
    // Stores destinations from the ArrayList into the input file .
    public void readDestinations(Scanner fileScanner)
    {
      // Reads whole file.
        while(fileScanner.hasNextLine())
        {
            String temp = fileScanner.nextLine();

          // Splits the read line with delimiter 
            String[] delim = temp.split("[;\\-]");
           
            if (delim.length != 6)
            {
                System.out.println("ERROR: Incorrect file format.");
                System.exit(1);
            }

           // Adds each segment of the line to the destinations ArrayList.
            destinations.add(new Destination(delim[0], Integer.parseInt(delim[1]), Integer.parseInt(delim[2]),
                    Integer.parseInt(delim[3]), Integer.parseInt(delim[4]), Integer.parseInt(delim[5])));
        }
    }

    
      // Uses the sort method to sort miles.
    private void sortDestinations()
    {
        destinations.sort((d1, d2) -> d2.getNormalMiles() - d1.getNormalMiles());
    }

    
      //  uses algorithm to get tickets to be redeemed
    public ArrayList<String> redeemMiles(int miles, int month)
    {
        ArrayList<String> redeemedTickets = new ArrayList<>();

        // Calls the sortDestination sorts from longest to shortest distance
        sortDestinations();

      // Gives the remaining miles
        remainMiles = miles;

        String temp;

        // loops through destinations Array List and calls redeemTickets 
        for( Destination dest : destinations)
        {
          // Temp stores the destination and  miles to upgrade.
            temp = dest.getDestinationCity() + ";" + dest.getAdditionalMiles();

            // If month greater than start month and less than end month, use super saver miles, otherwise use normal miles.
            if( month >= dest.getStartMonth() && month <= dest.getEndMonth())
                redeemedTickets = redeemTickets(redeemedTickets, temp, dest.getSuperSaverMiles());
            else
                redeemedTickets = redeemTickets(redeemedTickets, temp, dest.getNormalMiles());
        }

          // Calls the upgradeTickets to check if it's eligible for upgrade.
        redeemedTickets = upgradeTickets(redeemedTickets);

        return redeemedTickets;
    }

      
    // If remaining tickets are less than ticket miles, return tickets, otherwise subtract the needed miles from the remaining miles.   
    private ArrayList<String> redeemTickets(ArrayList<String> tickets, String cityAndUpgrade, int ticketMiles)
    {
        if( remainMiles < ticketMiles )
            return tickets;
        else
        {
            remainMiles = remainMiles - ticketMiles;
            tickets.add(cityAndUpgrade);
            return tickets;
        }
    }
    
  // Return remaining miles
      public int getRemainMiles()
    {
        return remainMiles;
    }

      
    // method is used to upgrade tickets with remaining miles and format.
    private ArrayList<String> upgradeTickets(ArrayList<String> tickets)
    {
        String[] delim;
        int temp;

        
        for(int i = 0; i < tickets.size(); i++)
        {
           delim = tickets.get(i).split(";");
           temp = Integer.parseInt(delim[1]);

            // If remaining miles are greater or equal to temp set to first clas. Otherwise set to economy class.
            if( remainMiles >= temp)
            {
                remainMiles = remainMiles - temp;
                tickets.set(i, String.format("* You can get a first class ticket to %s ",delim[0]));
            }
            else
                tickets.set(i, String.format("* You can get an economy class ticket to %s ",delim[0]));
        }

        return tickets;
    }
    
    
     // This gets the destination associated with the city name.
    public Destination findDestination( String cityName )
    {
        Destination findDest = new Destination();
        // Loops through ArrayList to find a matching city name.
        for (Destination dest : destinations)
        {
            if ( dest.getDestinationCity().equals(cityName) )
               findDest = dest;
        }
         return  findDest;
     }
    

}
