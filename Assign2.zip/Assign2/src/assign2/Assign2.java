/*
 * Assignment 2
 * Name: Lukus Hendrix
 * ZID: Z1761354
 * CSCI 470
 * Date Due: 3/21/18
 * Description: This program will calculate the number of flight tickets
 * available as the user submits their miles and date. If the user doesn't travel
 * in a busy season then the super save can be used which accumulates less miles
 * and perhaps first class. Then it will calculate your remaining miles.
 * This is all accomplished with jswing for a GUI user interface experience.
*/
package assign2;


import java.io.FileNotFoundException;
import javax.swing.*;
import java.io.File;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import java.text.DateFormatSymbols;
import java.time.Month;
import java.util.ArrayList;
import java.util.Scanner;

public class Assign2
{

    // Variables
    private static JFrame frame;
    private static MilesRedeemer miles;
    

    // This method will create all panels for the GUI using JFrame.
    private static void createGUI()
    {
        // Using a 12 pt font.
        Font entryFont = new Font("TimesNewRoman", Font.PLAIN, 12);

        // Makes left panel BorderLayout, sets the color and labels.
        JPanel leftPan = new JPanel( new BorderLayout( 11, 11) );
        leftPan.setBackground( new Color( 163, 200,240));
        leftPan.setBorder( BorderFactory.createTitledBorder("List of Destination Cities"));

        // Makes right panel BorderLayout, sets the color and labels.
        JPanel rightPan = new JPanel( new BorderLayout( 7, 7 ));
        rightPan.setBackground( new Color ( 253, 222, 96));
        rightPan.setBorder( BorderFactory.createTitledBorder("Redeem Tickets"));

        // Makes JList to contain the names of each destination.
        JList<String> cityNames = new JList<>( miles.getCityNames() );
         cityNames.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
         cityNames.setFixedCellWidth(5);
         cityNames.setVisibleRowCount(9);
         cityNames.setFont( entryFont );

        // A JScrollPane is created to contain the city names.
        JScrollPane city = new JScrollPane(cityNames);

        // Uses JPanel to contain the information of the selected city. Sets GridLayout, 4 rows, 2 columns, hgap 10, and vgap 16       
        JPanel dataPanel = new JPanel( new GridLayout( 4, 2, 10, 16));
        dataPanel.setBackground( new Color(134,243,188) );

        // Makes JLabel for required miles.
        JLabel milesReqLabel = new JLabel(" Required Miles:" );
        milesReqLabel.setFont( entryFont );
        dataPanel.add( milesReqLabel);

        // Uses JTextField for the required miles.
        JTextField requiredMilesText = new JTextField(1);
        requiredMilesText.setFont( entryFont );
        requiredMilesText.setEditable( false );
        requiredMilesText.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        dataPanel.add( requiredMilesText );

        // Uses JLabel miles for upgrading.
        JLabel upgradeLabel = new JLabel(" Miles for Upgrading:" );
        upgradeLabel.setFont( entryFont );
        dataPanel.add(upgradeLabel);

        // Uses JTextField as miles required for upgrading.
        JTextField upgradeText = new JTextField(1);
        upgradeText.setFont( entryFont );
        upgradeText.setEditable( false );
        upgradeText.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        dataPanel.add( upgradeText );

        // Makes JLabel for the supersaver miles.
        JLabel superMilesLabel = new JLabel(" Miles for SuperSaver:" );
        superMilesLabel.setFont( entryFont );
        dataPanel.add(superMilesLabel);

        // Makes JTextField for the supersaver miles.
        JTextField superSaverText = new JTextField(1);
        superSaverText.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        superSaverText.setFont( entryFont );
        superSaverText.setEditable( false );
        dataPanel.add( superSaverText );

        // Makes JLabel for the supersaver months.
        JLabel superMonthsLabel = new JLabel( " Months for SuperSaver:" );
        superMonthsLabel.setFont( entryFont );
        dataPanel.add(superMonthsLabel);

        // Uses JTextField for the supersaver months.
        JTextField superMonthsText = new JTextField(1);
        superMonthsText.setFont( entryFont );
        superMonthsText.setEditable( false );
        superMonthsText.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        dataPanel.add( superMonthsText );

        // Uses listener for the JList to update the data displayed.
        cityNames.addListSelectionListener(new ListSelectionListener()
        {
            @Override
            public void valueChanged(ListSelectionEvent e)
            {
                Destination dest;
                if(!e.getValueIsAdjusting())
                {
                    // Uses the dest object for the selected city.
                    dest = miles.findDestination( cityNames.getSelectedValue() );

                    String start;
                    String end;

 
                    // Uses the JTextFields to display the destination data for selected city.
                    requiredMilesText.setText( Integer.toString( dest.getNormalMiles() ) );
                    upgradeText.setText( Integer.toString( dest.getAdditionalMiles() ) );
                    superSaverText.setText( Integer.toString(dest.getSuperSaverMiles() ) );

                    // Displays the months using DateFormatSymbols() 
                    // This finds the start and end months for the supersaver months.
                    start = new DateFormatSymbols().getMonths()[dest.getStartMonth() - 1];
                    end = new DateFormatSymbols().getMonths()[dest.getEndMonth() - 1];

                    // Sets the JTextField to the start and end months for the supersaver months.
                    superMonthsText.setText( start + " to " + end );
                }
            }
        });

        // Sets JScrollPanel and JPanel to the left panel.
        leftPan.add( city, BorderLayout.PAGE_START );
        leftPan.add( dataPanel, BorderLayout.CENTER );

        // This  tixPanel is  a JPanel that stores data of the miles to redeem.
        JPanel tixPanel = new JPanel( new GridLayout( 3, 1, 10, 16));
        tixPanel.setBackground( new Color(246 , 243, 243) );

        // This accumMilesPanel is a JPanel for accumulated miles.
        JPanel accumMilesPanel = new JPanel( new FlowLayout( FlowLayout.CENTER ));
        accumMilesPanel.setOpaque( false );

        // This accumText is a JTextField used to input the number of miles.
        JTextField accumText = new JTextField(14);
        accumText.setHorizontalAlignment( SwingConstants.RIGHT );

        // Adds JLabel and JTextField to the accumulated miles JPanel.
        accumMilesPanel.add( new JLabel( "Your Accumulated Miles ") );
        accumMilesPanel.add( accumText );

        // This departMonthPanel is a JPanel for the departure month.
        JPanel departMonthPanel = new JPanel( new FlowLayout( FlowLayout.CENTER));
        departMonthPanel.setOpaque( false );

        // Uses the a JSpinner and populates it with the months from the getMonthStrings() method.
        SpinnerListModel monthModel = new SpinnerListModel( getMonthStrings() );
        JSpinner monthSpinner = new JSpinner( monthModel );
        monthSpinner.setPreferredSize( new Dimension( 100, 20));

        //  Adds JLabel and JSpinner to the departure month JFrame.
        departMonthPanel.add( new JLabel( "Month of Departure "));
        departMonthPanel.add( monthSpinner );

        // This creates a JPanel and JButton to redeem the tickets.
        JPanel redeemPanel = new JPanel( new FlowLayout( FlowLayout.CENTER));
        redeemPanel.setOpaque( false );
        JButton redeemButton = new JButton("Redeem Ticket >>> ");
        redeemPanel.add( redeemButton );

        // This creates the JTextArea to store the results into res for ticket redemption.
        JTextArea res = new JTextArea(8, 40);
        res.setFont( entryFont );
        res.setEditable( false );

        // This creates the JPanel to store remaining miles.
        JPanel remainMilesPanel = new JPanel( new FlowLayout( FlowLayout.CENTER ));
        remainMilesPanel.setOpaque( false );

        // Creates the JTextField to hold the remaining miles.
        JTextField remainMiles = new JTextField(14);
         remainMiles.setEditable( false );
         remainMiles.setBorder(javax.swing.BorderFactory.createEmptyBorder());
         remainMiles.setHorizontalAlignment( SwingConstants.RIGHT );

        // This action listener is used to listen when the redeemButton is pushed.
        redeemButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                // declarations of variables
                ArrayList<String> tix;
                int redeemMiles = -1;

                // Trys to convert the given miles into an integer, if unable it throws an exception.
                try
                {
                    redeemMiles = Integer.parseInt(accumText.getText());
                }
                catch (NumberFormatException ex)
                {
                    System.out.println( "ERROR: Invalid number " );
                }

                //    Gets the departure month
                int departMonth = Month.valueOf(monthSpinner.getValue().toString().toUpperCase()).getValue();

                //  If the redeemMiles is  > = 0 then it will run the redeemMiles method using the
                //   data provided and print out the display in the result JTextField.
                if ( redeemMiles >= 0 )
                {
                    tix = miles.redeemMiles( redeemMiles, departMonth);

                    res.setText( "\n Your accumulated miles can be used to redeem the following air tickets:  \n\n");

                    // Checks if there are enogh miles to redeem, else  prints out the tickets available for redemption.
                    if ( tix.isEmpty() )
                        res.append(" There are not enough miles to redeem a ticket.\n");
                    else
                        tix.forEach(s -> res.append(" " + s + "\n"));

                    // Stores all of the remaining miles in the remainMiles JTextField.
                    remainMiles.setText( Integer.toString( miles.getRemainMiles() ) );
                }
            }
        });

        // Adds the ticket data panels to the created tixPanel
        tixPanel.add( accumMilesPanel );
        tixPanel.add( departMonthPanel );
        tixPanel.add( redeemPanel );

        // Puts the remainMiles Panel JLabel and JTextField to the JPanel.
        remainMilesPanel.add( new JLabel("Your Remaining Miles") );
        remainMilesPanel.add( remainMiles );

        // Sets the ticket data, results, and remaining miles JPanels to the right JPanel.
        rightPan.add( tixPanel, BorderLayout.PAGE_START );
        rightPan.add( res, BorderLayout.CENTER );
        rightPan.add( remainMilesPanel, BorderLayout.PAGE_END );

        // Adds left and right JPanel to the JFrame.
        frame.add( leftPan, BorderLayout.LINE_START );
        frame.add( rightPan, BorderLayout.CENTER );
    }


    //  This method uses the DateFormatSymbols to allocate the String array months.
    private static String[] getMonthStrings()
    {
        String[] month = new String[12];
        for (int i = 0; i < 12; i++)
        {
            month[i] = new DateFormatSymbols().getMonths()[i];
        }

        return month;
    }

    // The main method.
    public static void main(String[] args)
    {

        // Variables
        Scanner scanner;
        File file = new File("miles.txt");

        // Initializes the MilesRedeemer class to miles.
        miles = new MilesRedeemer();

        //  Throws an error and exits the program if it can't read given file.
        try
        {
            scanner = new Scanner(file);
            miles.readDestinations(scanner);

        }
        
        //File not found Exception
        catch (FileNotFoundException e) 
        {
            System.out.println(String.format("ERROR: File \"%s\" does not exist.", args[0]));
            System.exit(1);
        }

        // Utilizes and displays the JFrame
        SwingUtilities.invokeLater(new Runnable()
        {
            @Override
            public void run()
            {
                // This creates the JFrame, sets the title, dimensions, and default close operation.
                frame = new JFrame( "Airline Milage Redemtion");
                frame.setPreferredSize(new Dimension( 950, 350 ));
                frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );

                // This creates and adds the JFrame components.
                createGUI();

                // This displays the frame
                frame.pack();
                frame.setVisible( true );
            }
        });
    }  
}

