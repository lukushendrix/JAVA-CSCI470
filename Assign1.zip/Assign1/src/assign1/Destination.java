/* Assignment 1
 * Name: Lukus Hendrix
 * ZID z1761354
 * Due: 2/21/18
 * Description: Creates constructor for destination and returns 
 *              setter and getter methods.
 */
package assign1;


    public class Destination {
        
    private String destinationCity;
    private int normalMiles;
    private int additionalMiles;
    private int superSaverMiles;
    private int startMonth;
    private int endMonth;
    
 // Constructor
    
    public Destination(String newDestinationCity, int newNormalMiles, int newSuperSaverMiles, int newAdditionalMiles, int newStartMonth, int newEndMonth ) 
    {
      destinationCity = newDestinationCity;
      normalMiles = newNormalMiles;
      additionalMiles = newAdditionalMiles;
      superSaverMiles = newSuperSaverMiles;
      startMonth = newStartMonth;
      endMonth = newEndMonth;
      
      
    }
    
    public String getDestinationCity()
    {
        return destinationCity;
    }
    
    public void setDestinationCity(String newDestinationCity)
    {
        destinationCity = newDestinationCity;
    }
    
    public int getNormalMiles()
    {
        return normalMiles;
    }
    
    public void setNormalMiles(int newNormalMiles)
    {
        normalMiles = newNormalMiles;
    }
    
    public int getAdditionalMiles()
    {
        return additionalMiles;
               
    }
    
    public void setAdditionalMiles(int newAdditionalMiles)
    {
         additionalMiles = newAdditionalMiles;
    }
    
    public int getSuperSaverMiles()
    {
        return superSaverMiles;
    }
    
    public void setSuperSaverMiles(int newSuperSaverMiles)
    {
        superSaverMiles = newSuperSaverMiles;
    }
    
    public int getStartMonth()
    {
        return startMonth;
    }
    
    public void setStartMonth(int newStartMonth)
    {
        startMonth = newStartMonth;
    }
    
    public int getEndMonth()
    {
        return endMonth;
    }
    
    public void setEndMonth(int newEndMonth)
    {
        endMonth = newEndMonth;
    }
    
}
