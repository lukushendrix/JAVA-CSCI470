/*
 * Assignment 1
 * Name: Lukus Hendrix
 * ZID: Z1761354
 * CSCI 470
 * Date Due: 2/21/18
 * Description: This program will calculate the number of flight tickets
 * available as the user submits their miles and date. If the user doesn't travel
 * in a busy season then the super save can be used which accumulates less miles
 * and perhaps first class. Then it will calculate your remaining miles.
 *
*/
package assign1;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;


public class Assign1 {
         

   
    public static void main(String[] args) throws FileNotFoundException {
       
       MilesRedeemer miles = new MilesRedeemer();
       Scanner scan ;
       String temp;
       char inp;
       int milesToRedeem;
       int month;
       ArrayList<String> tix;
      
     
       
      File file = new File("miles.txt");
             
       try 
       {                 
           scan = new Scanner(file);
           miles.readDestinations(scan);
           
           
       }
       catch (FileNotFoundException e)
       {
          
          System.exit(1);
           
       }
  
        //Main loop , it calls the miles redeemer class to display output
                 while( true)
                {
                    System.out.println("-----------------------------------------------\n" + 
                            "List of distination cities you can travel to: \n"); 
                    
                    for (String city : miles.getCityNames())
                        System.out.println(city);
                    System.out.println("-----------------------------------------------");
                    
                    scan = new Scanner(System.in);
                    while (true)
                    {
                        System.out.print("\nPlease input you total accumulated miles: ");
                        temp = scan.next();
                        System.out.print("\n");
                        try
                        {
                            milesToRedeem = Integer.parseInt(temp);
                            break;
                        }
                        catch (NumberFormatException e)
                        {
                            System.out.println("Error: input was not a number. ");
                            
                        }
                    }
                    
                   // Getting the accumulated miles
                    while(true)
                    {
                        System.out.print("\nPlease input your month of departue (1-12): ");
                        temp = scan.next();
                        
                        try
                        {
                            month = Integer.parseInt(temp);
                            if(month < 13 && month > 0)
                                break;
                            else
                                System.out.println("Please input a number between 1 and 12: ");
                        }
                        catch (NumberFormatException e)
                        {
                             System.out.println("Error: input was not a number."); 
                            
                        }
                    }
                    
                    tix = miles.redeemMiles(milesToRedeem, month);
                    
                    System.out.println();
                    
                    tix.forEach(s -> System.out.println(s));
                    System.out.println("\nYour remaining miles: " + miles.getRemainMiles() );
                    
                    // asks if you want to continue and converts char to lower case
                    do
                    {
                        System.out.print("\nDo you want to continue (y/n)? ");
                        temp = scan.next();
                        inp = temp.toLowerCase().charAt(0);
                        
                        if (inp != 'y' && inp != 'n')
                            System.out.println("Please only enter y for yes or n for no.\n");
                    } 
                        while (inp != 'y' && inp != 'n');
                    if (inp == 'n')
                        break;
                    System.out.println();
                   
                    
                }
        
    }
    
}
