/*
 * Assignment 3
 * Name: Lukus Hendrix
 * ZID: Z1761354
 * CSCI 470
 * Date Due: 4/4/18
 * Description: This class holds most of the user interface for the album information 
 *              downloaded and handles action events from the “Get Albums” button.
 *               
*/
package assign3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class XMLDownloadPanel extends JPanel implements ActionListener, AlbumDisplayer
{
    private JButton getAlbums;
    private JTextArea albumInfo;
    private XMLDownloadTask task;
    private String feedType = "new-music";
    private int resLimit = 10;
    private boolean explicit = true;

    // Default constructor
    public XMLDownloadPanel()
    {
        // Sets to BorderLayout
        super();
        setLayout( new BorderLayout() );

        // Adds an ActionListener and creates the "Get Album" button.
       
            getAlbums = new JButton("Get Albums");
            getAlbums.addActionListener( this );

      // Creates 10 row and 60 columns for the text area album information to be displayed,
      // then it sets editable to false.
           albumInfo = new JTextArea(10, 60);
           albumInfo.setEditable( false );

        // Creates the panel for Get Albums button.
        JPanel buttonPanel = new JPanel( new FlowLayout( FlowLayout.CENTER ) );
        buttonPanel.add(getAlbums);

        // uses a scroll pane for the text area.
        JScrollPane scroll = new JScrollPane(albumInfo);

        // adds button panel also scroll pane to the downloadPanel.
        add(buttonPanel, BorderLayout.PAGE_START);
        add(scroll, BorderLayout.CENTER);
    }

    // This action performed will clear the text area then calls the download method.
    @Override
    public void actionPerformed(ActionEvent e)
    {
        albumInfo.setText("");
        download();
    }

    // This method will constructs a url string to download, then passes it into a task
    // created by XMLDownloadTask, then execute the task.
   
    public void download()
    {
        String url = String.format("https://rss.itunes.apple.com/api/v1/us/itunes-music/%s/all/%d/%s.atom",
                 feedType, resLimit, explicit ? "explicit" : "non-explicit");

        task = new XMLDownloadTask( this, url );

        // This propertyChangeListener is used to disable the getAlbums button when the task is running.
        task.addPropertyChangeListener(event ->
        {
           switch ((SwingWorker.StateValue) event.getNewValue())
           {
             case STARTED:
                  getAlbums.setEnabled( false );
                   break;

             case DONE:
                  getAlbums.setEnabled( true );
                   break;
           }
        });

        task.execute();
    }

    // Accessors for the feedType variable.
    public String getFeedType(){ return feedType; }
    public void setFeedType( String newFeedType ){ feedType = newFeedType; }

    // Accessors for the resLimit variable.
    public int getResultLimit(){ return resLimit; }
    public void setResultLimit( int newLimit ){ resLimit = newLimit; }

    // Accessors for the explicit variable.
    public boolean getExplicit(){ return explicit; }
    public void setExplicit( boolean newExplicit ){ explicit = newExplicit; }

    // Appends the album information that passed to the albumInfo text area.
    public void displayAlbums( Album album )
    {
        albumInfo.append(album.getAlbumName());
        albumInfo.append("; ");
        albumInfo.append(album.getArtistName());
        albumInfo.append("; ");
        albumInfo.append(album.getGenre());
        albumInfo.append("\n");
    }
}